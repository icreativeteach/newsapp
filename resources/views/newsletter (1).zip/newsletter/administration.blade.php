
<div class="sw-card sw-product-detail-specification__measures-packaging">
	<div class="sw-card__title">
          
    </div>
    <div class="sw-card__content">
    	<div class="sw-container">
<h2>Randall Graves</h2>
<p>"In light of this lurid tale, I don't even see how you can romanticize your relationship with Caitlin. She broke your heart and inadvertently drove men to deviant lifestyles."</p>
	</div>
    </div> 
</div>