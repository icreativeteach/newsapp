<!-- <a href="javascript:void(0)" data-toggle="tooltip" onClick="recipientgroupEdit({{ $id }})" data-original-title="Edit" class="edit btn btn-success edit">
Edit
</a> -->
<a href="javascript:void(0);" id="delete-recipientgroup" onClick="recipientDelete({{ $id }})" data-toggle="tooltip" data-original-title="Delete" class="delete btn btn-danger">
Delete
</a>