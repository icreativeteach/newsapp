<div class="sw-card">
   <div class="sw-card__title">
          
    </div>
    <div class="sw-card__content custom-recipient-subtab">
      @include('newsletter.recipient.recipients')
    </div>    
</div>
