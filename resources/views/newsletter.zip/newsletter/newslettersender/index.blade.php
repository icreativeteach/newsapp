<div class="sw-card">
   <div class="sw-card__title">
          
    </div>
    <div class="sw-card__content custom-subtab">
      <?php /* @include('newsletter.newslettersender.list')
      @include('newsletter.newslettersender.create')
      @include('newsletter.newslettersender.edit') */ ?>
      @include('newsletter.newslettersender.senders')
    </div>
    
</div>

