@extends('base')

@section('title', 'Newsletter Management')
@section('stylesheets')

@endsection
@section('body')
<!-- <button id="button_print" style="margin: 10px" onclick="printOrderList()">Print order list</button> -->
<div class="sw-tabs sw-tabs--small tabs">
    <div class="sw-tabs__content" style="padding-bottom: 0px;" id="tabs-nav"> 
        <ul>
            <li>
                <a href="#tab1" class="sw-tabs-item" title="General">
                    Overview
                </a>
            </li>
            <li> 
                <a href="#tab2" class="sw-tabs-item" title="Products">
                    Analytics
                </a> 
            </li>
            <li>
                <a href="#tab3" class="sw-tabs-item" title="Theme">
                    Administration
                </a> 
            </li>
        </ul>
    </div>
</div>

<div id="tabs-content">
    <div id="tab1" class="tab-content">
        @include('newsletter.overview-data')
    </div>
    <div id="tab2" class="tab-content">
        @include('newsletter.analytics')
    </div>
    <div id="tab3" class="tab-content">
        @include('newsletter.administration')
    </div>

  </div>



<?php

//@include('order.order-list-table', ['orderListConfiguration' => $orderListConfiguration])

?>
@endsection

@section('javascripts')
<script type="text/javascript">
    // Show the first tab and hide the rest
$('#tabs-nav li:first-child').addClass('active');
$('.tab-content').hide();
$('.tab-content:first').show();

// Click function
$('#tabs-nav li').click(function(){
  $('#tabs-nav li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content').hide();
  
  var activeTab = $(this).find('a').attr('href');
  $(activeTab).fadeIn();
  return false;
});
</script>
@endsection