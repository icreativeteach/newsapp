<div class="sw-card">
   <div class="sw-card__title">
          
    </div>
    <div class="sw-card__content custom-recipientgroup-subtab">
      @include('newsletter.recipientgroup.list')
      @include('newsletter.recipientgroup.create')
      @include('newsletter.recipientgroup.edit')
    </div>    
</div>
