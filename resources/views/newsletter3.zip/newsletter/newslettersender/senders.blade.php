<div class="container mt-2">
   <div class="row">
      <div class="col-lg-12 margin-tb">
         <div class="pull-left">
            <h2>Laravel 8 Ajax CRUD DataTables Tutorial</h2>
         </div>
         <div class="pull-right mb-2">
            <a class="btn btn-success" onClick="add()" href="javascript:void(0)"> Create Company</a>
         </div>
      </div>
   </div>
   @if ($message = Session::get('success'))
   <div class="alert alert-success">
      <p>{{ $message }}</p>
   </div>
   @endif
   <div class="card-body">
      <table class="table table-bordered" id="ajax-crud-datatable">
         <thead>
            <tr>
               <th>Id</th>
               <th>Email</th>
               <th>Name</th>
               <th>Action</th>
            </tr>
         </thead>
      </table>
   </div>
</div>
<!-- boostrap company model -->
<div class="modal fade" id="company-modal" aria-hidden="true">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title" id="CompanyModal"></h4>
         </div>
         <div class="modal-body">
            <form action="javascript:void(0)" id="CompanyForm" name="CompanyForm" class="form-horizontal" method="POST" enctype="multipart/form-data">
               <input type="hidden" name="id" id="id">
               <div class="form-group">
                  <label for="email" class="col-sm-2 control-label">Sender email</label>
                  <div class="col-sm-12">
                    
                     <input type="text" name="email" id="email" placeholder="Enter Email Address" class="form-control email" required="">
                  </div>
               </div>
               <div class="form-group">
                  <label for="name" class="col-sm-2 control-label">Sender name</label>
                  <div class="col-sm-12">
                     <input type="text" name="name" id="name" placeholder="Enter Sender Name" class="form-control name" required="">
                  </div>
               </div>
               
               <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-primary" id="btn-save">Save changes
                  </button>
               </div>
            </form>
         </div>
         <div class="modal-footer"></div>
      </div>
   </div>
</div>