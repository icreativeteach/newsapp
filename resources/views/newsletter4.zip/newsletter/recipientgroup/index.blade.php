<div class="sw-card">
   <div class="sw-card__title">
          
    </div>
    <div class="sw-card__content custom-recipientgroup-subtab">
    <?php  /*@include('newsletter.recipientgroup.list')
      @include('newsletter.recipientgroup.create')
      @include('newsletter.recipientgroup.edit') */  ?>
      @include('newsletter.recipientgroup.recipientgroups')
    </div>    
</div>
