<div class="sw-card">
	<div class="sw-card__title">
          
    </div>
    <div class="sw-card__content">
    	@include('newsletter.newslettersender.list')
    </div>
</div>
        @include('newsletter.newslettersender.create')
    
</div>
</div>


@section('javascripts')
   @include('newsletter.scripts.newslettersender')
@endsection