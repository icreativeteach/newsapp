<div class="newsletter-sender-create-form">
  <div class="sw-container">
      <form action="" id="form1" method="POST">
        <!-- @csrf -->
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" class="email"><br><br>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" class="name"><br><br>
         <input type="reset" value="Clear">
        <input type="submit" value="Submit" class="newsletter-btn-submit">
      </form>
  </div>      
</div>