<script type="text/javascript">
$('.newsletter-sender-create-form').hide(); 
$('.newsletter-btn-create-sender').click(function(){
	$('.newsletter-sender-create-form').show(); 
    $('.newsletter-sender-list').hide();
	
});
$(document).on('click', '.newsletter-btn-submit', function (e) { 
    e.preventDefault();
    //alert("called");
    var email=$('.email').val();
    var name=$('.name').val();
    alert(email);
    alert(name);
    $.ajax
    ({
        type:'POST',
        url: "{{ url('newslettersender/store') }}",
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data:{email : email,name : name},
       // dataType:"string",
        success: function(data){
        	//alert(":gkhkj");
            console.log(data);
            // if(data == "formatnotmatch")
            // {
            //     $(".uniqueidMsg").css("display", "block");
            //     $(".uniqueidMsg").text("Please check your UniqueId.");
            // }
            // if(data == "false")
            // {
            //     $(".uniqueidMsg").css("display", "block");
            //     $(".uniqueidMsg").text("Please check your UniqueId.");
            // }
            // if(data == "true")
            // {
            //      $(".uniqueidMsg").css("display", "none");
            //      //$(".uniqueidMsg").text("UniqueId correct.");
            // }
           
            //$(".quantity").val(data[0].qty);
            //$("#hiddenquantity").val(data[0].qty);
        },
     error: function () {
       alert('error');
       console.log("errorr");
     }
    });

});

</script>