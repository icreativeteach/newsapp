<div class="sw-card sw-product-detail-specification__measures-packaging">
    <div class="sw-card__title">
          
    </div>
      <div class="sw-card__content">
        <div class="sw-container">
            <div class="sw-tabs sw-tabs--small tabs">
                <div class="sw-tabs__content" style="padding-bottom: 0px;" id="tabs-nav"> 
                    <ul class="child">
                        <li>
                            <a href="#tab2-1" class="sw-tabs-item" title="General">
                                Conversion rates
                            </a>
                        </li>
                        <li> 
                            <a href="#tab2-2" class="sw-tabs-item" title="Products">
                                Orders
                            </a> 
                        </li>
                    </ul>
                </div>
            </div>

            <div id="tabs-content">
                <div id="tab2-1" class="tab-content">
                    <h2>11</h2>
                    <p>"My friend here's trying to convince me that any independent contractors who were working on the uncompleted Death Star were innocent victims when it was destroyed by the Rebels."</p>
                   <?php //  @include('newsletter.overview-data') ?>
                </div>
                <div id="tab2-2" class="tab-content">

                    <h2>22</h2>
                    <p>"My friend here's trying to convince me that any independent contractors who were working on the uncompleted Death Star were innocent victims when it was destroyed by the Rebels."</p>
                    <?php //@include('newsletter.analytics') ?>
                </div>
                

            </div>

            <h2>Dante Hicks</h2>
            <p>"My friend here's trying to convince me that any independent contractors who were working on the uncompleted Death Star were innocent victims when it was destroyed by the Rebels."</p>
        </div>
    </div>
</div>