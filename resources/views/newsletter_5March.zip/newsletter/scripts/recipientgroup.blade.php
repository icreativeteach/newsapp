<script type="text/javascript">
  //default on page load
// $('.newsletter-sender-create-form').hide();
// $('.newsletter-sender-edit-form').hide(); 
// $('.deletesender-bulk').hide();

//click of create sender button
// $('.newsletter-btn-create-sender').click(function(){
//     $('.newsletter-sender-create-form').show(); 
//     $('.newsletter-sender-list').hide();
//     $('.newsletter-sender-edit-form').hide();
// });

recipientgroup-create-form
recipientgroup-btn-create-cancel
recipientgroup-btn-create
createRecipientGroup
recipientGroupName


recipientgroup-list
custom-actions
btn-create-recipientgroup
custom-lisitng-box
deleterecipientgroup
delete-recipientgroup-count
delete-selectedrecipientgroup

</script>