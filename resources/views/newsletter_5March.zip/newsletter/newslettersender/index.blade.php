<div class="sw-card">
   <div class="sw-card__title">
          
    </div>
    <div class="sw-card__content custom-subtab">
      @include('newsletter.newslettersender.list')
      @include('newsletter.newslettersender.create')
      @include('newsletter.newslettersender.edit')
    </div>
    
</div>
        
    



@section('javascripts')
   @include('newsletter.scripts.newslettersender')
@endsection